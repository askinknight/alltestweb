export {};
//# sourceMappingURL=templates.test.d.ts.map